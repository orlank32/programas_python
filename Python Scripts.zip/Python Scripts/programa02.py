a = 20
b = 10
soma = a + b
print("A soma é", soma)
x = 10
y = 15
soma02 = x + y
print("A soma é", soma02)
soma03 = 5.5
print("soma=", soma03)

a = 10

b = 30

a = a + 10

b = a + 10

a = a + b
print(a)
