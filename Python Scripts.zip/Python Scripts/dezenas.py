x = int(input("Digite um número inteiro: "))
y = (x//10)%10 
print("O dígito das dezenas é", y)
