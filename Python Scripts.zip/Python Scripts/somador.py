x = int(input("Digite um número: "))
soma = 0
while x > 0:
    algarismo = x%10
    soma = soma + algarismo
    x = x // 10

print("A soma dos numeros é: ", soma)

i = 6
while (i > 0):          
    i = i - 3    
    print (i) 
