x = int(input("Digite um número: "))
if x%2==0:
    print("par")
else:
    print("ímpar")
