def test_dislexia():
    print("Bem-vindo ao Teste de Dislexia")
    print("Leia as palavras abaixo e digite-as corretamente.")
    words = ["cavalo", "direito", "macaco", "trocar", "correto"]
    errors = 0

    for word in words:
        user_input = input(f"Digite a palavra: {word} - ").strip().lower()
        if user_input != word:
            print("Incorreto!")
            errors += 1
        else:
            print("Correto!")

    print("\nResultado do teste:")
    if errors > 3:
        print("Você pode apresentar sinais de dislexia.")
    else:
        print("Você não apresenta sinais evidentes de dislexia.")

if __name__ == "__main__":
    test_dislexia()


import random

# Lista de palavras para o teste (algumas com erros de soletração)
palavras = ["cachorro", "gato", "flores", "camiseta", "democracia", "escosseia", "peroqueto", "preferir", "paralizar"]

def executar_teste():
    pontuacao = 0

    print("Bem-vindo ao teste de leitura. Identifique as palavras com erros de soletração.")
    
    for i in range(5):
        palavra = random.choice(palavras)
        print(f"Palavra {i+1}: {palavra}")
        
        resposta = input("Esta palavra está soletrada corretamente? (s/n): ")
        
        if resposta.lower() == "n" and palavra not in palavras:
            pontuacao += 1
        elif resposta.lower() == "s" and palavra in palavras:
            pontuacao += 1

    print(f"Você acertou {pontuacao} de 5 palavras.")
    
    if pontuacao <= 2:
        print("É recomendável procurar avaliação profissional para avaliar suas habilidades de leitura.")
    else:
        print("Seus resultados são razoáveis, mas uma avaliação profissional pode ser útil para uma avaliação mais precisa.")

if __name__ == "__main__":
    executar_teste()

