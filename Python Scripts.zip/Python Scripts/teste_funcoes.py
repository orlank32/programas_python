def total_Caracteres (x, y, z):
    return len(x)+len(y)+len(z)

def leitura():
    x = -1
    while x <= 0:
        x = int(input("Digite um valor: "))
    return x

import math

def suspense(x):
    return math.sqrt(x)
