def soma(x, y):
    return x + y
def multiplica(x, y):
    return x * y
    
def multiplica3(x,y,z):
    return x * y * z

def nome_do_seu_time ():
    return str(input("Que time é teu ?"))

