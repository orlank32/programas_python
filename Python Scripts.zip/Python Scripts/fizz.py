x = int(input("Digite um número: "))
if x%3==0:
    print("Fizz")
else:
    print(x)
