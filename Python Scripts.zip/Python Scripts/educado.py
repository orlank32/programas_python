nomemae = input("Qual o nome da sua mãe ? ")
nomepai = input("Qual o nome do seu pai ? ")
print("Bom dia senhora", nomemae, "e bom dia senhor", nomepai, "!")
