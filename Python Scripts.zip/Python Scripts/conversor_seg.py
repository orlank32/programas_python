seg_total=int(input("Insira uma quantidade de segundos: "))
dias = seg_total//86400
seg_total %= 86400
horas = seg_total//3600
seg_total %= 3600
seg_resto = seg_total%86400
minutos = seg_resto//60
segundos = seg_resto%60
print(dias, "dias,", horas,"horas,", minutos, "minutos e", segundos, "segundos.")

