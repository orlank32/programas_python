ano = float(input("Digite uma ano: "))
bissexto=(ano%4==0 and ano!=0) or (ano%400==0)
print("O ano é bissexto", bissexto)
