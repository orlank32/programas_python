tempF = int(input("Insira o valor da temperatura em Farenheit: "))
tempC = (tempF - 32)*5/9
print("A temperatura em Farenheit é: ", tempC)
