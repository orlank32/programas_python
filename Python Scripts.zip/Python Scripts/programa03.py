x = 50

y = 20

aux = x

x = y

y = aux

print(y)

a = 1
b = 2
print(a+2*b)
