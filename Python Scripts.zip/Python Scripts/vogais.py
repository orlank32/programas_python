def vogal(caractere):
    if len(caractere) == 1 and caractere.isalpha():
        vogais = "aeiouAEIOU"
        return caractere.lower() in vogais.lower()
    else:
        return False
