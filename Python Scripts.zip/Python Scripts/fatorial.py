def fatorial (n):
    fat = 1
    while n > 1:
        fat = fat * n
        n = n - 1
    return fat

def num_binomial(n, k):
    return fatorial(n)/(fatorial(k)*fatorial(n-k))

def teste_fatorial ():
    if fatorial(0) == 1:
        print("O fatorial de 0 funfa e é", fatorial(0))
    else:
        print("Não funfa")
    if fatorial(1) == 1:
        print("O fatorial de 1 funfa e é", fatorial(1))
    else:
        print("Não funfa")
    if fatorial(2) == 2:
        print("O fatorial de 2 funfa e é", fatorial(2))
    else:
        print("Não funfa")
    if fatorial(5) == 120:
        print("O fatorial de 5 funfa e é", fatorial(5))
    else:
        print("Não funfa")
