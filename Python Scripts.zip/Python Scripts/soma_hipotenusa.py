def eh_hipotenusa(hipotenusa, cateto1, cateto2):
    return hipotenusa**2 == cateto1**2 + cateto2**2

def soma_hipotenusas(n):
    soma = 0

    for hipotenusa in range(1, n + 1):
        hipotenusa_adicionada = False  # Flag para verificar se a hipotenusa já foi somada
        for cateto1 in range(1, hipotenusa):
            for cateto2 in range(cateto1, hipotenusa):
                if eh_hipotenusa(hipotenusa, cateto1, cateto2) and not hipotenusa_adicionada:
                    soma += hipotenusa
                    hipotenusa_adicionada = True  # Marcar a hipotenusa como adicionada

    return soma
