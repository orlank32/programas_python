x = int(input("Digite um número inteiro: "))
if x <= 1:
    print("não primo")
else:
    primo = True

i = 2
import math
while i <= int(math.sqrt(x)):
    if x % i == 0:
        primo = False
        break
    i = i + 1


if primo:
    print("primo")
else:
    print("não primo")

