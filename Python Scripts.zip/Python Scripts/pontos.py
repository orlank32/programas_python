import math
x1=int(input("x¹: "))
x2=int(input("x²: "))
y1=int(input("y¹: "))
y2=int(input("y²: "))

d = math.sqrt((x1-x2)**2 + (y1-y2)**2)
if d < 10:
    print("perto")
else:
    print("longe")
