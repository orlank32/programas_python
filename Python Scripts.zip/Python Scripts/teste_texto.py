texto = "computação"
if len (texto) > 10:
    print("texto com mais de 10 caracteres")
else:
    print("texto com 10 ou menos caracteres")
