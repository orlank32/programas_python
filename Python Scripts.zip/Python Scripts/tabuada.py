def mod_1():
    linha = 1
    coluna = 1
    while linha <= 10:
        while coluna <= 10:
            print(f"{linha} X {coluna} = {linha * coluna}\t", end="")
            coluna = coluna + 1
        print()  # Nova linha após cada conjunto de 10 colunas
        coluna = 1  # Reinicia a contagem de colunas para a próxima linha
        linha = linha + 1
        print()  # Nova linha entre as linhas
        

        
def mod_2():
    linha = 1
    while linha <= 10:
        coluna = 1  # Reinicializa a coluna para cada linha
        while coluna <= 10:
            x = int(input(f"{linha} X {coluna} = "))
            correto = x == linha * coluna
            if correto:
                print("Correto!")
            else:
                print("A respota correta é", linha * coluna)
            coluna = coluna + 1
        linha = linha + 1
        print()

def mod_3():
    certo = 0
    erro = 0
    linha = 1
    while linha <= 10:
        coluna = 1  # Reinicializa a coluna para cada linha
        while coluna <= 10:
            x = int(input(f"{linha} X {coluna} = "))
            correto = x == linha * coluna
            if correto:
                print("Correto!")
                certo = certo + 1
            else:
                print("Errado!")
                erro = erro + 1
            coluna = coluna + 1
        linha = linha + 1
        print()
        print("Você teve", certo, "acerto(s) e", erro, "erro(s).")
        
def mod_4():
    jogadores = ["Jogador 1", "Jogador 2"]
    certo = [0, 0]
    erro = [0, 0]
    vez_do_jogador = 0
    linha = 1
    while linha <= 10:
        coluna = 1  # Reinicializa a coluna para cada linha
        while coluna <= 10:
            x = int(input(f"{linha} X {coluna} = "))
            correto = x == linha * coluna
            if correto:
                print("Correto!")
                certo[vez_do_jogador] += 1
            else:
                print("Errado!")
                erro[vez_do_jogador] += 1
            coluna = coluna + 1
            vez_do_jogador = 1 - vez_do_jogador

        linha = linha + 1
        print()
        
    for i, jogador in enumerate(jogadores):
        print(f"{jogador} teve {certo[i]} acerto(s) e {erro[i]} erro(s).")

while True:
    print("**** Tabuada ****")
    print("**** Modo de jogo ****")
    print("1 - Imprimir tabuada")
    print("2 - Aprendizado")
    print("3 - Computar erros")
    print("4 - Competição")
    print("0 - Sair do programa")

    opcao = int(input())
    
    if opcao == 1:
        print("1 - Imprimir tabuada")
        mod_1()
    elif opcao == 2:
        print("2 - Aprendizado")
        mod_2()
    elif opcao == 3:
        print("3 - Computar erros")
        mod_3()
    elif opcao == 4:
        print("4 - Competição")
        mod_4()
    elif opcao == 0:
        print("Saindo...")
        break
    else:
        print("Opção inválida! Tente novamente.")
