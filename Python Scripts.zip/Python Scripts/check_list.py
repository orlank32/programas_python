Python 3.11.1 (tags/v3.11.1:a7a450f, Dec  6 2022, 19:58:39) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

=== RESTART: C:/Users/orlan/OneDrive/Documentos/Python Scripts/check_list.py ===

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 1
Digite a tarefa que deseja adicionar: Estudar desenvolvimento web e programação
Tarefa 'Estudar desenvolvimento web e programação' adicionada com sucesso!

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 1
Digite a tarefa que deseja adicionar: Continuar o desenvolvimento da página para a exposição no MES
Tarefa 'Continuar o desenvolvimento da página para a exposição no MES' adicionada com sucesso!

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 1
Digite a tarefa que deseja adicionar: Organizar leituras e materiais para a reunião de amanhã e o colegiado de domingo.
Tarefa 'Organizar leituras e materiais para a reunião de amanhã e o colegiado de domingo.' adicionada com sucesso!

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 1
Digite a tarefa que deseja adicionar: Ler Zaratustra e Walter Benjamin
Tarefa 'Ler Zaratustra e Walter Benjamin' adicionada com sucesso!

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 2

Lista de Tarefas:
1. Estudar desenvolvimento web e programação
2. Continuar o desenvolvimento da página para a exposição no MES
3. Organizar leituras e materiais para a reunião de amanhã e o colegiado de domingo.
4. Ler Zaratustra e Walter Benjamin

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 3

Lista de Tarefas:
1. Estudar desenvolvimento web e programação
2. Continuar o desenvolvimento da página para a exposição no MES
3. Organizar leituras e materiais para a reunião de amanhã e o colegiado de domingo.
4. Ler Zaratustra e Walter Benjamin

Digite o número da tarefa concluída: 2
Tarefa 'Continuar o desenvolvimento da página para a exposição no MES' marcada como concluída!

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 2

Lista de Tarefas:
1. Estudar desenvolvimento web e programação
2. Organizar leituras e materiais para a reunião de amanhã e o colegiado de domingo.
3. Ler Zaratustra e Walter Benjamin

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 1
Digite a tarefa que deseja adicionar: Estudar as disciplinas da faculdade
Tarefa 'Estudar as disciplinas da faculdade' adicionada com sucesso!

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
Escolha uma opção: 2

Lista de Tarefas:
1. Estudar desenvolvimento web e programação
2. Organizar leituras e materiais para a reunião de amanhã e o colegiado de domingo.
3. Ler Zaratustra e Walter Benjamin
4. Estudar as disciplinas da faculdade

Opções:
1. Adicionar Tarefa
2. Listar Tarefas
3. Marcar Tarefa como Concluída
4. Sair
