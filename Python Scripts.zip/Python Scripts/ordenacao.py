x = int(input("Digite um número: "))
y = int(input("Digite um número: "))
z = int(input("Digite um número: "))

if (x < y < z):
    print("Crescente")
else:
    print("Não está em ordem crescente.")
