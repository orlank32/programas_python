# Função para a escolha da jogada do computador
def computador_escolhe_jogada(n, m):
    if n % (m + 1) == 0:
        return m  # Deve retirar m peças para deixar um múltiplo de (m+1)
    else:
        return n % (m + 1)  # Deve retirar o necessário para deixar um múltiplo de (m+1)

# Função para a escolha da jogada do usuário
def usuario_escolhe_jogada(n, m):
    jogada = int(input("Quantas peças você vai tirar? "))
    while jogada < 1 or jogada > m or jogada > n:
        print("Jogada inválida")
        jogada = int(input("Quantas peças você vai tirar? "))
    return jogada

# Função para executar uma partida
def partida():
    n = int(input("Quantas peças? "))
    m = int(input("Limite de peças por jogada? "))
    if n % (m + 1) == 0:
        print("Você começa!")
        vez_do_computador = False
    else:
        print("Computador começa!")
        vez_do_computador = True
    while n > 0:
        if vez_do_computador:
            jogada = computador_escolhe_jogada(n, m)
            print("\nO computador tirou", jogada, "peças.")
        else:
            jogada = usuario_escolhe_jogada(n, m)
            print("\nVocê tirou", jogada, "peças.")

        n = n - jogada
        print("Agora restam", n, "peças.")
        vez_do_computador = not vez_do_computador

    if vez_do_computador:
        print("Você venceu!")
        return "Você"
    else:
        print("Fim de jogo! O computador ganhou!")
        return "Computador"

# Função para executar um campeonato
def campeonato():
    vitorias_usuario = 0
    vitorias_computador = 0

    for _ in range(3):
        print(f"\n**** Rodada {_ + 1} ****")
        resultado_partida = partida()

        if resultado_partida == "Você":
            vitorias_usuario += 1
        else:
            vitorias_computador += 1

    print("\n**** Final do campeonato! ****")
    print(f"Placar: Você {vitorias_usuario} X {vitorias_computador} Computador")

# Estrutura principal
print("Bem-vindo ao jogo do NIM! Escolha:")
print("1 - para jogar uma partida isolada")
print("2 - para jogar um campeonato")

opcao = int(input())
if opcao == 1:
    print("Você escolheu uma partida isolada!")
    partida()
elif opcao == 2:
    print("Você escolheu um campeonato!")
    campeonato()
else:
    print("Opção inválida!")
