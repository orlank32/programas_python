L = int(input("Insira um valor para o lado do quadrado: "))
x = 4*L
y = L**2
print("perímetro:", x, "- área:",y)
