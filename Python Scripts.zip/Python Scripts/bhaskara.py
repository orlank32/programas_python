import math

# Receber os parâmetros da equação do usuário
a = float(input("Digite o valor de a: "))
b = float(input("Digite o valor de b: "))
c = float(input("Digite o valor de c: "))

# Calcular o discriminante
delta = b**2 - 4*a*c

# Verificar as condições e calcular as raízes
if delta < 0:
    print("esta equação não possui raízes reais")
elif delta == 0:
    # Uma raiz real (raiz com multiplicidade 2)
    raiz = -b / (2*a)
    print(f"a raiz desta equação é {raiz}")
else:
    # Duas raízes reais distintas
    raiz1 = (-b + math.sqrt(delta)) / (2*a)
    raiz2 = (-b - math.sqrt(delta)) / (2*a)
    # Ordenar as raízes em ordem crescente
    raiz1, raiz2 = min(raiz1, raiz2), max(raiz1, raiz2)
    print(f"as raízes da equação são {raiz1} e {raiz2}")
