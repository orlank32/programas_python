resultado = 20.0/3
print(resultado)