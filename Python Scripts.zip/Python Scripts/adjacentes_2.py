x = int(input("Digite um número inteiro: "))
ultimo_digito = x % 10
x = x // 10
adjacentes_iguais = False

while x > 0:
    digito_atual = x % 10
    if digito_atual == ultimo_digito:
        adjacentes_iguais = True
        break
        
    ultimo_digito = digito_atual
    x = x//10

if adjacentes_iguais:
    print("sim")
else:
    print("não")
    
