#primeira função
def computador_escolhe_jogada (n, m):
    if n%(m+1)==0:
        return m
    else:
        return n%(m+1)
#segunda função         
def usuario_escolhe_jogada(n, m):
    jogada = int(input("Quantas peças você vai tirar ?"))
    while jogada < 1 or jogada > m or jogada > n:
        print("Jogada inválida")
        jogada = int(input("Quantas peças você vai tirar ?"))
    return jogada
#terceira função
def partida():
    n = int(input("Quantas peças ?"))
    m = int(input("Limite de peças por jogada ?"))
    if n%(m+1) == 0:
        print("Computador começa!")
        vez_do_computador = True
    else:
        print("Você começa!")
        vez_do_computador = False
    while n > 0:
        if vez_do_computador:
            jogada = computador_escolhe_jogada(n, m)
            print("\nO computador tirou", jogada, "peças.")
        else:
            jogada = usuario_escolhe_jogada(n, m)
            print("\nVocê tirou", jogada, "peças.")

        n = n - jogada
        print("Agora restam", n, "peças.")
        vez_do_computador = not vez_do_computador

    if vez_do_computador:
        print("Você venceu !")
    else:
        print("Fim de jogo ! O computador ganhou !")
#quarta função
def campeonato():
    vitorias_usuario = 0
    vitorias_computador = 0

    for _ in range(3):
        print(f"\n**** Rodada {_ + 1} ****")
        resultado_partida = partida()

        if "Você" in resultado_partida:
            vitorias_usuario += 1
        else:
            vitorias_computador += 1

    print("\n**** Final do campeonato! ****")
    print(f"Placar: Você {vitorias_usuario} X {vitorias_computador} Computador")

#Estrutura principal
print("Bem-vindo ao jogo do NIM! Escolha:")
print("1 - para jogar uma partida isolada")
print("2 - para jogar um campeonato 2")

opcao = int(input())
if opcao == 1:
    print("Você escolheu uma partida isolada!")
    partida()
elif opcao == 2:
    print("Voce escolheu um campeonato!")
    campeonato()
else:
    print(("Opção inválida !"))
    

    
        
    
