print("Qual medida será convertida ? C/F: ")
opcao = input().upper()
if opcao == "C":
    C = float(input("Informe a temperatura em °C: "))
    fh = (1.8*C)+32
    print("A temperatura de {}°C corresponde à {}°F".format(C, fh))
elif opcao == "F":
    Fh = float(input("Informe a temperutura em °F: " ))
    c = (Fh - 32)/1.8
    print("A temperatura de {}°F correponde à {}°C".format(Fh, c))
else:
    print("Opção inválida, escolha C ou F.")
