d = int(input("Quantos dias foi alugado: "))
km = float(input("Quantos km rodados :"))
prec = (60*d) + (0.15*km)
print("O total a pagar é R$ {:.2f}".format(prec))
