prec = float(input("Qual o preço do produto ? R$ "))
perc = float(input("Porcentagem do desconto: "))
desc = prec - (prec * perc / 100)
print("O preço do produto que custava R${} com o desconto de {:.0f}% agora custa R${:.2f}.".format(prec, perc, desc))
