a = input("Digite algo: ")
print("O tipo primitivo é:", type(a))
