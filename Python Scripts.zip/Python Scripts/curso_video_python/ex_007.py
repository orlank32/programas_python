n1 = float(input("Nota 1: "))
n2 = float(input("Nota 2: "))
print("A média entre as notas {:.1f} e {:.1f} é {:.1f}".format(n1, n2, (n1+n2)/2))
