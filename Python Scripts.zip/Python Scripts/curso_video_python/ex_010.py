real = float(input("Quanto você tem na carteira ? R$"))
dolar = real * 0.21
euro = real * 0.19
print("Com R${} você pode comprar US${:.2f} \nCom R${} você pode comprar £${:.2f}".format(real, dolar, real, euro))
