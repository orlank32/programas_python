n = int(input("Digite um número: "))
print("Analisando o valor {}, seu antecessor é {} e seu sucessor é {}.".format(n, n - 1, n + 1))
