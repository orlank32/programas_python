sal = float(input("Qual o salário do funcionário ? R$ "))
perc = float(input("Porcentagem do aumento: "))
novo = sal*(1+perc/100)
print("O funcionário que ganhava R${:.2f} com o aumento de {:.0f}% agora passa a receber R${:.2f}.".format(sal, perc, novo))
