n = input("Digite seu nome: ")
print("É um prazer te conhecer, {}!".format(n),)
