nota = float(input("Digite uma nota: "))
resultado = 3 < nota < 5
print("A nota está no intervalo (3.0, 5.0): ", resultado)
